from scipy.stats import chisquare
from numpy import genfromtxt
# import matplotlib.pyplot as plt
from scipy import stats
import pandas as pd
import numpy as np
import itertools as it
from bisect import bisect_left
from typing import List
import scipy.stats as ss
from pandas import Categorical



def VD_A(treatment: List[float], control: List[float]):
    """
    Computes Vargha and Delaney A index
    A. Vargha and H. D. Delaney.
    A critique and improvement of the CL common language
    effect size statistics of McGraw and Wong.
    Journal of Educational and Behavioral Statistics, 25(2):101-132, 2000
    The formula to compute A has been transformed to minimize accuracy errors
    See: http://mtorchiano.wordpress.com/2014/05/19/effect-size-of-r-precision/
    :param treatment: a numeric list
    :param control: another numeric list
    :returns the value estimate and the magnitude
    """
    m = len(treatment)
    n = len(control)

    if m != n:
        raise ValueError("Data d and f must have the same length")

    r = ss.rankdata(treatment + control)
    r1 = sum(r[0:m])

    # Compute the measure
    # A = (r1/m - (m+1)/2)/n # formula (14) in Vargha and Delaney, 2000
    A = (2 * r1 - m * (m + 1)) / (2 * n * m)  # equivalent formula to avoid accuracy errors

    levels = [0.147, 0.33, 0.474]  # effect sizes from Hess and Kromrey, 2004
    magnitude = ["negligible", "small", "medium", "large"]
    scaled_A = (A - 0.5) * 2

    magnitude = magnitude[bisect_left(levels, abs(scaled_A))]
    estimate = A

    return estimate, magnitude

def VD_A_DF(data, val_col: str = None, group_col: str = None, sort=True):
    """
    :param data: pandas DataFrame object
        An array, any object exposing the array interface or a pandas DataFrame.
        Array must be two-dimensional. Second dimension may vary,
        i.e. groups may have different lengths.
    :param val_col: str, optional
        Must be specified if `a` is a pandas DataFrame object.
        Name of the column that contains values.
    :param group_col: str, optional
        Must be specified if `a` is a pandas DataFrame object.
        Name of the column that contains group names.
    :param sort : bool, optional
        Specifies whether to sort DataFrame by group_col or not. Recommended
        unless you sort your data manually.
    :return: stats : pandas DataFrame of effect sizes
    Stats summary ::
    'A' : Name of first measurement
    'B' : Name of second measurement
    'estimate' : effect sizes
    'magnitude' : magnitude
    """

    x = data.copy()
    if sort:
        x[group_col] = Categorical(x[group_col], categories=x[group_col].unique(), ordered=True)
        x.sort_values(by=[group_col, val_col], ascending=True, inplace=True)

    groups = x[group_col].unique()

    # Pairwise combinations
    g1, g2 = np.array(list(it.combinations(np.arange(groups.size), 2))).T

    # Compute effect size for each combination
    ef = np.array([VD_A(list(x[val_col][x[group_col] == groups[i]].values),
                        list(x[val_col][x[group_col] == groups[j]].values)) for i, j in zip(g1, g2)])

    return pd.DataFrame({
        'A': np.unique(data[group_col])[g1],
        'B': np.unique(data[group_col])[g2],
        'estimate': ef[:, 0],
        'magnitude': ef[:, 1]
    })

if __name__ == '__main__':

    mtl_file_name = 'Meta_deeparch-SizeReduction-3tasks_main0_meta[1, 2]_2_60-4096_01-23_15-39-23.txt'
    deepperf_file_name = 'Meta_deeparch-SizeReduction-3tasks_main0_meta[1, 2]_2_60-4096_12-28_22-45-40.txt'

    # selected_tasks = [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
    # selected_meta_model = 0
    selected_tasks = [0,1,2,3,4,5]

    raw_data = pd.read_csv(mtl_file_name)

    # read the corresponding deepperf results
    system = mtl_file_name.split('_')[1]
    main_task = mtl_file_name.split('_')[2].replace('main', '')
    N_train = mtl_file_name.split('_')[5]
    seed = mtl_file_name.split('_')[4]
    # deepperf_file_name = 'Deepperf_{}_{}_{}.txt'.format(system, seed, N_train)
    deepperf_data = pd.read_csv(deepperf_file_name)
    # print(raw_data.shape)
    # print(raw_data.values)

    # print(deepperf_data.shape)
    # print(deepperf_data.values)


    deepperf_dict = {}
    deepperf_count = {}
    mtl_dict = {}
    mtl_count = {}
    mtl_runs = []
    deepperf_runs = []

    # extract the maximum number of runs
    max_run = 0
    mtl_max_run = 0
    current_run = 0
    for i in range(raw_data.shape[0]):
        if len(''.join(raw_data.values[i]).split(' ')) > 1:
            if ''.join(raw_data.values[i]).split(' ')[0] == 'Run':
                # current_run = int(''.join(raw_data.values[i]).split(' ')[1])
                current_run += 1
                mtl_runs.append(int(''.join(raw_data.values[i]).split(' ')[1]))
                if current_run > mtl_max_run:
                    mtl_max_run = current_run

    deepperf_max_run = 0
    current_run = 0
    for i in range(deepperf_data.shape[0]):
        if len(''.join(deepperf_data.values[i]).split(' ')) > 1:
            if ''.join(deepperf_data.values[i]).split(' ')[0] == 'Run':
                # current_run = int(''.join(deepperf_data.values[i]).split(' ')[1])
                current_run += 1
                deepperf_runs.append(int(''.join(deepperf_data.values[i]).split(' ')[1]))
                if current_run > deepperf_max_run:
                    deepperf_max_run = current_run
    max_run = min(mtl_max_run, deepperf_max_run)
    print('Max run: {}'.format(max_run))

    # read mtl results
    for i in range(raw_data.shape[0]):
        if len(''.join(raw_data.values[i]).split(' ')) > 3:
            if ''.join(raw_data.values[i]).split(' ')[2] == 'MTL':
                task = ''.join(raw_data.values[i]).split(' ')[1]
                value = float(''.join(raw_data.values[i]).split(':')[1].strip())
                # print(float(''.join(raw_data.values[i]).split(':')[1].strip()))
                if task not in mtl_dict:
                    mtl_dict[task] = [value]
                else:
                    mtl_dict[task].append(value)
            else:
                print(
                    '---Error reading the text file! System = {}---'.format(''.join(raw_data.values[i]).split(' ')[0]))
        elif len(''.join(raw_data.values[i]).split(' ')) > 1:
            if ''.join(raw_data.values[i]).split(' ')[0] == 'Run':
                current_run = int(''.join(raw_data.values[i]).split(' ')[1])
            if current_run > max_run:
                break

    # read deepperf results
    for i in range(deepperf_data.shape[0]):
        if len(''.join(deepperf_data.values[i]).split(' ')) > 3:
            if ''.join(deepperf_data.values[i]).split(' ')[2] == 'MTL':
                task = ''.join(deepperf_data.values[i]).split(' ')[1]
                value = float(''.join(deepperf_data.values[i]).split(':')[1].strip())
                # print(float(''.join(deepperf_data.values[i]).split(':')[1].strip()))
                if task not in deepperf_dict:
                    deepperf_dict[task] = [value]
                else:
                    deepperf_dict[task].append(value)
            else:
                print(
                    '---Error reading the text file! System = {}---'.format(''.join(raw_data.values[i]).split(' ')[0]))
        elif len(''.join(deepperf_data.values[i]).split(' ')) > 1:
            if ''.join(deepperf_data.values[i]).split(' ')[0] == 'Run':
                current_run = int(''.join(deepperf_data.values[i]).split(' ')[1])
            if current_run > max_run:
                break


    for task in mtl_dict:
        print('Task {}:'.format(task))
        Q1 = np.percentile(deepperf_dict[task], 25, interpolation='midpoint')
        Q3 = np.percentile(deepperf_dict[task], 75, interpolation='midpoint')
        IQR = Q3 - Q1
        print('Deepperf Med(IQR) ({} runs) : {}({:.2f}), mean: {:.2f}'.format(len(deepperf_dict[task]),
                                                            round(np.median(deepperf_dict[task]), 2), IQR, np.mean(deepperf_dict[task])))
        Q1 = np.percentile(mtl_dict[task], 25, interpolation='midpoint')
        Q3 = np.percentile(mtl_dict[task], 75, interpolation='midpoint')
        IQR = Q3 - Q1
        print('MTL Med(IQR) ({} runs) : {}({:.2f}), mean: {:.2f}'.format(len(mtl_dict[task]), round(np.median(mtl_dict[task]), 2), IQR, np.mean(mtl_dict[task])))
        print(stats.wilcoxon(deepperf_dict[task], mtl_dict[task]))
        print(stats.ranksums(deepperf_dict[task], mtl_dict[task]))
        print('Effect size: ', VD_A(deepperf_dict[task], mtl_dict[task]))