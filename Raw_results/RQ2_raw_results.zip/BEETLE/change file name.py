import os, sys

temp_files = os.listdir(os.getcwd())

for file in temp_files:

    if (file.startswith("Meta") and file.endswith(".txt")):

        newName=file.replace("Meta","Beetle")#这一句的效果是直接删除QL

        os.rename(os.path.join(os.getcwd(), file), os.path.join(os.getcwd(), newName))
