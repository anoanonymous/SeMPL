import os, sys

temp_files = os.listdir(os.getcwd())

for file in temp_files:

    if (file.startswith("Meta_spear-10286-3tasks") and file.endswith(".txt")):
        newName = file.replace('3tasks', '6tasks')
        os.rename(os.path.join(os.getcwd(), file), os.path.join(os.getcwd(), newName))

        # newName = file.replace('main0', 'main3')
        # os.rename(os.path.join(os.getcwd(), file), os.path.join(os.getcwd(), newName))

        # file_data = ""
        # with open(file, "r") as f:
        #     for line in f:
        #         line = line.replace('Task 0', 'Task 3')
        #         file_data += line
        # with open(file, "w") as f:
        #     f.write(file_data)
